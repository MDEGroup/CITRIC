package de.tudresden.atl.drivers.tudemf4atl;

import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.eclipse.emf.common.util.Enumerator;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.util.FeatureMap;
import org.eclipse.m2m.atl.drivers.emf4atl.ASMEMFModel;
import org.eclipse.m2m.atl.drivers.emf4atl.ASMEMFModelElement;
import org.eclipse.m2m.atl.engine.vm.StackFrame;
import org.eclipse.m2m.atl.engine.vm.nativelib.ASMBag;
import org.eclipse.m2m.atl.engine.vm.nativelib.ASMBoolean;
import org.eclipse.m2m.atl.engine.vm.nativelib.ASMCollection;
import org.eclipse.m2m.atl.engine.vm.nativelib.ASMEnumLiteral;
import org.eclipse.m2m.atl.engine.vm.nativelib.ASMInteger;
import org.eclipse.m2m.atl.engine.vm.nativelib.ASMModel;
import org.eclipse.m2m.atl.engine.vm.nativelib.ASMOclAny;
import org.eclipse.m2m.atl.engine.vm.nativelib.ASMOclUndefined;
import org.eclipse.m2m.atl.engine.vm.nativelib.ASMReal;
import org.eclipse.m2m.atl.engine.vm.nativelib.ASMSequence;
import org.eclipse.m2m.atl.engine.vm.nativelib.ASMSet;
import org.eclipse.m2m.atl.engine.vm.nativelib.ASMString;
import org.eclipse.m2m.atl.engine.vm.nativelib.ASMTuple;

/**
 * @author Jendrik Johannes
 */
public class ASMTUDEMFModelElement extends ASMEMFModelElement {

    protected ASMTUDEMFModelElement(Map modelElements, ASMModel model, EObject object) {
        super(modelElements, model, object);
    }
    
    private ASMOclAny eObjectToASM(StackFrame frame, EObject value) {
        ASMEMFModel model = (ASMEMFModel) getModel();
        Resource valueExtent = value.eResource();
        if (model.getExtent().equals(valueExtent)) {
            return model.getASMModelElement(value);
        } else {
            Iterator models = frame.getModels().values().iterator();
            while (models.hasNext()) {
                Object m = models.next();
                if ((m instanceof ASMEMFModel) && (!model.equals(m))) {
                    if (((ASMEMFModel)m).getExtent().equals(valueExtent)) {
                        return ((ASMEMFModel)m).getASMModelElement(value);
                    }
                }
            }
        }
        //Use this model as proxy
        return model.getASMModelElement(value);
    }
    
    public ASMOclAny emf2ASM(StackFrame frame, Object value) {
        ASMOclAny ret = null;
        
        if(value instanceof String) {
            ret = new ASMString((String)value);
        } else if(value instanceof Boolean) {
            ret = new ASMBoolean(((Boolean)value).booleanValue());
        } else if(value instanceof Double) {
            ret = new ASMReal(((Double)value).doubleValue());
        } else if(value instanceof Float) {
            ret = new ASMReal(((Float)value).doubleValue());
        } else if(value instanceof Integer) {
            ret = new ASMInteger(((Integer)value).intValue());
        } else if(value instanceof Long) {
            ret = new ASMInteger(((Long)value).intValue());
        } else if(value instanceof Byte) {
            ret = new ASMInteger(((Byte)value).intValue());
        } else if(value instanceof Short) {
            ret = new ASMInteger(((Short)value).intValue());
        } else if(value instanceof Character) {
            ret = new ASMInteger(((Character)value).charValue());
        } else if(value instanceof Enumerator) {
            ret = new ASMEnumLiteral(((Enumerator)value).getName());
        } else if(value instanceof FeatureMap.Entry) {
            ret = new ASMTuple();
            ret.set(frame, "eStructuralFeature", 
                    emf2ASM(frame, ((FeatureMap.Entry)value).getEStructuralFeature()));
            ret.set(frame, "value", 
                    emf2ASM(frame, ((FeatureMap.Entry)value).getValue()));
        } else if(value instanceof EObject) {
            ret = eObjectToASM(frame, (EObject)value);
        } else if(value == null) {
            ret = new ASMOclUndefined();
        } else if(value instanceof Collection) {
            ASMCollection col;
            if(value instanceof List)
                col = new ASMSequence();
            else if(value instanceof Set)
                col = new ASMSet();
            else
                col = new ASMBag();
            
            for(Iterator i = ((Collection)value).iterator() ; i.hasNext() ; ) {
                col.add(emf2ASM(frame, i.next()));
            }
            ret = col;
        } else {
            ret = new ASMString(value.toString());
        }
        
        return ret;
    }

}
