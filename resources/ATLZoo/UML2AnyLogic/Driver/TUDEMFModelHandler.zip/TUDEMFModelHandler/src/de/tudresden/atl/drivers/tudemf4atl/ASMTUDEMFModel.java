package de.tudresden.atl.drivers.tudemf4atl;

import java.io.InputStream;
import java.net.URL;

import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.m2m.atl.drivers.emf4atl.ASMEMFModel;
import org.eclipse.m2m.atl.engine.vm.ModelLoader;
import org.eclipse.m2m.atl.engine.vm.nativelib.ASMModelElement;

/**
 * @author Jendrik Johannes
 */
public class ASMTUDEMFModel extends ASMEMFModel {

	protected ASMTUDEMFModel(String name, Resource extent, ASMEMFModel metamodel, boolean isTarget, ModelLoader ml) {
        super(name, extent, metamodel, isTarget, ml);
    }

    public ASMModelElement getASMModelElement(EObject object) {
		ASMModelElement ret = null;
		
		synchronized(modelElements) {
			ret = (ASMModelElement)modelElements.get(object);
			if(ret == null) {
				ret = new ASMTUDEMFModelElement(modelElements, this, object);
			}
		}
		
		return ret;
	}

    
    public static ASMTUDEMFModel loadASMTUDEMFModel(String name, ASMEMFModel metamodel, Resource extent, ModelLoader ml) throws Exception {
        ASMTUDEMFModel ret = null;
        
        ret = new ASMTUDEMFModel(name, extent, metamodel, false, ml);
        
        return ret;
    }
    
    /**
     * Creates a new ASMEMFModel.
     * @param name The model name. Not used by EMF.
     * @param uri The model URI. EMF uses this to determine the correct factory.
     * @param metamodel
     * @param ml
     * @return
     * @throws Exception
     * @author Dennis Wagelaar <dennis.wagelaar@vub.ac.be>
     */
    public static ASMTUDEMFModel newASMTUDEMFModel(String name, String uri, ASMEMFModel metamodel, ModelLoader ml) throws Exception {
        ASMTUDEMFModel ret = null;
        Resource extent = null;
        
        synchronized (resourceSet) {
            extent = resourceSet.createResource(URI.createURI(uri));
        }

        ret = new ASMTUDEMFModel(name, extent, metamodel, true, ml);
        ret.unload = true;

        return ret;
    }
    
    public static ASMTUDEMFModel loadASMTUDEMFModel(String name, ASMEMFModel metamodel, String url, ModelLoader ml) throws Exception {
        ASMTUDEMFModel ret = null;
        
        if(url.startsWith("uri:")) {
            //only initialise on demand (after loading instance of this metamodel)
            String uri = url.substring(4);
            ret = new ASMTUDEMFModel(name, null, metamodel, false, ml);
            ret.resolveURI = uri;
        } else {
            ret = loadASMTUDEMFModel(name, metamodel, URI.createURI(url), ml);
        }
        
        return ret;
    }
    
    public static ASMTUDEMFModel loadASMTUDEMFModel(String name, ASMEMFModel metamodel, URL url, ModelLoader ml) throws Exception {
        ASMTUDEMFModel ret = null;

        ret = loadASMTUDEMFModel(name, metamodel, url.openStream(), ml);
        
        return ret;
    }
    
    public static ASMTUDEMFModel loadASMTUDEMFModel(String name, ASMEMFModel metamodel, URI uri, ModelLoader ml) throws Exception {
        ASMTUDEMFModel ret = null;

        try {
            Resource extent = null;
            synchronized (resourceSet) {
                extent = resourceSet.getResource(uri, true);
            }
            ret = new ASMTUDEMFModel(name, extent, metamodel, true, ml);
            ret.addAllReferencedExtents(extent);
            ret.setIsTarget(false);
            ret.unload = true;
        } catch(Exception e) {
//            logger.log(Level.SEVERE, e.getLocalizedMessage(), e);
          e.printStackTrace();
        }
        adaptMetamodel(ret, metamodel);

        return ret;
    }
    
    public static ASMTUDEMFModel loadASMTUDEMFModel(String name, ASMEMFModel metamodel, InputStream in, ModelLoader ml) throws Exception {
        ASMTUDEMFModel ret = newASMTUDEMFModel(name, name, metamodel, ml);

        try {
            synchronized (resourceSet) {
                ret.getExtent().load(in, resourceSet.getLoadOptions());
            }
            ret.addAllReferencedExtents(ret.getExtent());
            ret.unload = true;
        } catch(Exception e) {
//            logger.log(Level.SEVERE, e.getLocalizedMessage(), e);
          e.printStackTrace();
        }
        
        adaptMetamodel(ret, metamodel);
        ret.setIsTarget(false);

        return ret;
    }
	
}